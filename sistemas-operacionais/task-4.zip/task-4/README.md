# Execução
```
gcc one_dim_iterative_average.c && ./a.out <num-threads> <num-iterations>
```